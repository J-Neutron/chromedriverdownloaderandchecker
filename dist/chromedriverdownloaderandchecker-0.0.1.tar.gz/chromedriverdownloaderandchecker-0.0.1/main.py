from ChromeDriverDownloader import ChromeDriverDownloader

chrome_driver_path = 'C:\python\chromedriver'

chrome_browser_path = 'C:\Program Files\Google\Chrome\Application\chrome.exe'

ChromeDriverDownloader.check_driver(chrome_driver_path, chrome_browser_path)
